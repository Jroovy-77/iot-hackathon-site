@echo off
cd /d "%~dp0"
set PY=
where python >nul 2>nul && set PY=python
if not defined PY where py >nul 2>nul && set PY=py
if not defined PY (
  echo Python not found. Install Python from python.org, or open this folder in VS Code with Live Server.
  pause
  exit /b
)
start "" cmd /c "timeout /t 2 >nul & start http://localhost:8000/"
echo Site running at http://localhost:8000/  - close this window to stop.
%PY% -m http.server 8000
